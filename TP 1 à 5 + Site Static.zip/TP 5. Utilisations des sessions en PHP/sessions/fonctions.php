<?php
/**
 * Retourne une instance PDO connectée à la base de données monsite.
 */
function getBdd() {
    $host = 'localhost';
    $dbname = 'monsite';
    $user = 'monsite_util';
    $pass = 'secret';

    try {
        $bdd = new PDO(
            "mysql:host=$host;dbname=$dbname;charset=utf8",
            $user,
            $pass,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        return $bdd;
    } catch (PDOException $e) {
        die("Erreur de connexion à la base de données : " . $e->getMessage());
    }
}
