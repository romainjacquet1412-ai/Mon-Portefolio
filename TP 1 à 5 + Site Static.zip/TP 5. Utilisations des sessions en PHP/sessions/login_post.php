<?php
session_start(); // démarrage d'une session

// On vérifie que les données du formulaire sont présentes
if (isset($_POST['login']) && isset($_POST['mdp'])) {

    require 'fonctions.php';
    $bdd = getBdd();

    $login = $_POST['login'];
    $mdp   = $_POST['mdp'];

    // -------------------------------------------------------
    // AMÉLIORATION : on distingue login inconnu / mdp incorrect
    // -------------------------------------------------------

    // Étape 1 : vérifier si le login existe
    $requeteLogin = "SELECT * FROM utilis WHERE LoginUtil = ?";
    $stmtLogin = $bdd->prepare($requeteLogin);
    $stmtLogin->execute([$login]);
    $utilisateur = $stmtLogin->fetch(PDO::FETCH_ASSOC);

    if (!$utilisateur) {
        // Login introuvable
        header('Location: login.php?erreur=' . urlencode("Login inconnu. Veuillez réessayer."));
        exit;
    }

    // Étape 2 : vérifier le mot de passe
    if ($utilisateur['PassUtil'] !== $mdp) {
        // Login reconnu mais mot de passe incorrect
        header('Location: login.php?erreur=' . urlencode("Mot de passe incorrect pour ce login."));
        exit;
    }

    // Authentification réussie : on stocke les infos en session
    $_SESSION['login']   = $utilisateur['LoginUtil'];
    $_SESSION['mdp']     = $utilisateur['PassUtil'];
    $_SESSION['nom']     = $utilisateur['NomUtil'];
    $_SESSION['prenom']  = $utilisateur['PrenomUtil'];
    $_SESSION['numUtil'] = $utilisateur['NumUtil'];

    // Redirection vers la page d'accueil
    header('Location: index.php');
    exit;

} else {
    // Accès direct sans données POST
    header('Location: login.php');
    exit;
}
