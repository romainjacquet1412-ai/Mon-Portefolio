<?php
session_start();

// Si l'utilisateur n'est pas connecté, on le redirige vers le login
if (!isset($_SESSION['login'])) {
    header('Location: login.php');
    exit;
}

// AMÉLIORATION : on affiche le nom et le prénom, pas le login/mot de passe
$nom    = htmlspecialchars($_SESSION['nom']);
$prenom = htmlspecialchars($_SESSION['prenom']);
?>
<!doctype html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <title>Accueil</title>
    </head>
    <body>
        <h1>Page d'accueil</h1>

        <p>Bienvenue, <strong><?= $prenom . ' ' . $nom ?></strong> !</p>

        <p><a href="logout.php">Se déconnecter</a></p>
    </body>
</html>
