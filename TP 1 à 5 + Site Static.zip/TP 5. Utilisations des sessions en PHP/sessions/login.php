<!doctype html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <title>Connexion</title>
    </head>
    <body>
        <h1>Connexion utilisateur</h1>

        <?php
        // Affiche le message d'erreur transmis en GET si présent
        if (!empty($_GET['erreur'])) {
            echo '<p style="color:red;">' . htmlspecialchars($_GET['erreur']) . '</p>';
        }
        ?>

        <form action="login_post.php" method="post">
            <label for="nom">Nom :</label>
            <input type="text" name="login" id="nom" required />

            <label for="mdp">Mot de passe :</label>
            <input type="password" name="mdp" id="mdp" required />

            <input type="submit" value="Connexion">
        </form>
    </body>
</html>
