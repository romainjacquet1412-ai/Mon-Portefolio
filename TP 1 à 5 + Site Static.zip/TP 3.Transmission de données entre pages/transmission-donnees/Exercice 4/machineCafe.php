<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Machine à café</title>
</head>
<body>
    <h1>Votre boisson</h1>
    <form action="machineCafe.php" method="post">
        <label>Nom :
            <input type="text" name="nom">
        </label>
        <br>
        <label>Prénom :
            <input type="text" name="prenom">
        </label>
        <br><br>
        <label>Choisissez votre boisson :
            <select name="boisson">
                <option value="Café">Café</option>
                <option value="Thé">Thé</option>
                <option value="Chocolat">Chocolat</option>
                <option value="Café crème">Café crème</option>
            </select>
        </label>
        <br><br>
        <label><input type="radio" name="sucre" value="Oui" checked> Sucre</label><br>
        <label><input type="radio" name="sucre" value="Non"> Sans sucre</label>
        <br><br>
        <button type="submit" name="action" value="valider">Valider</button>
        <button type="submit" name="action" value="annuler">Annuler</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['action']) && $_POST['action'] === 'annuler') {
            echo "<p>Commande annulée.</p>";
        } elseif (isset($_POST['nom'], $_POST['prenom'], $_POST['boisson'], $_POST['sucre'])) {
            $nom     = htmlspecialchars($_POST['nom']);
            $prenom  = htmlspecialchars($_POST['prenom']);
            $boisson = htmlspecialchars($_POST['boisson']);
            $sucre   = htmlspecialchars($_POST['sucre']);

            echo "<p>Bonjour " . $prenom . " " . $nom . "</p>";
            echo "<p>Votre choix : " . $boisson . "</p>";
            echo "<p>Sucre : " . $sucre . "</p>";
        }
    }
    ?>
</body>
</html>
