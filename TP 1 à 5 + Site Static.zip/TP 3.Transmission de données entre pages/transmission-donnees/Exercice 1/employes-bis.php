<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des employés</title>
</head>
<body>
    <h1>Liste des employés</h1>
    <?php
    if (isset($_GET['nombre'])) {
        $nombre = (int) $_GET['nombre'];
        echo "<ul>";
        for ($i = 1; $i <= $nombre; $i++) {
            echo "<li>Employé " . $i . " : <a href='employe.php?id=" . $i . "'>détails</a></li>";
        }
        echo "</ul>";
    } else {
        echo "<p>Aucun nombre fourni !</p>";
    }
    ?>
</body>
</html>
