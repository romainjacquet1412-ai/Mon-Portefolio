<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bonjour</title>
</head>
<body>
    <form action="bonjour-bis.php" method="post">
        <label>Entrez votre prénom :
            <input type="text" name="prenom" required>
        </label>
        <br><br>
        <label>Cochez pour un bonjour plus familier :
            <input type="checkbox" name="familier" value="1">
        </label>
        <br><br>
        <label><input type="radio" name="civilite" value="Mademoiselle"> Mademoiselle</label><br>
        <label><input type="radio" name="civilite" value="Madame"> Madame</label><br>
        <label><input type="radio" name="civilite" value="Monsieur" checked> Monsieur</label>
        <br><br>
        <button type="submit">Dire bonjour</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['prenom']) && $_POST['prenom'] !== '') {
        $prenom   = htmlspecialchars($_POST['prenom']);
        $familier = isset($_POST['familier']);
        $civilite = isset($_POST['civilite']) ? htmlspecialchars($_POST['civilite']) : '';

        $salutation = $familier ? "Salut" : "Bonjour";

        if (!$familier && $civilite !== '') {
            echo "<p>" . $salutation . " " . strtolower($civilite) . " " . $prenom . " !</p>";
        } else {
            echo "<p>" . $salutation . " " . $prenom . " !</p>";
        }
    }
    ?>
</body>
</html>
