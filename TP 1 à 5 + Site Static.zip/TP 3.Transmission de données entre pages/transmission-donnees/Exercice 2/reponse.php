<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Réponse</title>
</head>
<body>
    <?php
    if (isset($_POST['prenom']) && $_POST['prenom'] !== '') {
        $prenom   = htmlspecialchars($_POST['prenom']);
        $familier = isset($_POST['familier']);
        $civilite = isset($_POST['civilite']) ? htmlspecialchars($_POST['civilite']) : '';

        $salutation = $familier ? "Salut" : "Bonjour";

        if (!$familier && $civilite !== '') {
            echo "<p>" . $salutation . " " . strtolower($civilite) . " " . $prenom . " !</p>";
        } else {
            echo "<p>" . $salutation . " " . $prenom . " !</p>";
        }
    } else {
        echo "<p>Aucun prénom fourni !</p>";
    }
    ?>
</body>
</html>
