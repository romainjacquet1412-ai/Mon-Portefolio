<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bonjour</title>
</head>
<body>
    <form action="reponse.php" method="post">
        <label>Entrez votre prénom :
            <input type="text" name="prenom" required>
        </label>
        <br><br>
        <label>Cochez pour un bonjour plus familier :
            <input type="checkbox" name="familier" value="1">
        </label>
        <br><br>
        <label><input type="radio" name="civilite" value="Mademoiselle"> Mademoiselle</label><br>
        <label><input type="radio" name="civilite" value="Madame"> Madame</label><br>
        <label><input type="radio" name="civilite" value="Monsieur" checked> Monsieur</label>
        <br><br>
        <button type="submit">Dire bonjour</button>
    </form>
</body>
</html>
