<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Service sélectionné</title>
</head>
<body>
    <?php
    if (isset($_POST['service'])) {
        $service = htmlspecialchars($_POST['service']);
        echo "<p>Le code du service choisi est " . $service . "</p>";
    } else {
        echo "<p>Aucun service sélectionné !</p>";
    }
    ?>
</body>
</html>
