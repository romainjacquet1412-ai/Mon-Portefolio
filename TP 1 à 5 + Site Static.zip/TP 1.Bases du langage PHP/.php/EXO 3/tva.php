<?php
  $prixHorsTaxes = 100;
  $tauxTVA = 19.6;
  $prixTTC = $prixHorsTaxes * (1 + $tauxTVA / 100);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Calcul de TVA</title>
</head>
<body>
  <h1>Calcul de TVA</h1>
  <ul>
    <li>Prix hors taxes = <?php echo $prixHorsTaxes; ?> &euro;</li>
    <li>Taux de TVA = <?php echo $tauxTVA; ?>%</li>
    <li>Prix TTC = <?php echo $prixTTC; ?> &euro;</li>
  </ul>
</body>
</html>
