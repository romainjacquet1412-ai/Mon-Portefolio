<?php
  $prenom     = "Romain";
  $classe     = 'BTS SIO';
  $nbLangages = 2;
?>
