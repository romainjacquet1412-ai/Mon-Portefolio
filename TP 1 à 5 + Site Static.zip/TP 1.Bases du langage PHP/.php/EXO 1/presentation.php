<?php
  $nom = "Romain";
  $age = 18;
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>La page de <?php echo $nom; ?></title>
</head>
<body>
  <h1>Bienvenue !</h1>
  <p>Bonjour, je m'appelle <?php echo $nom; ?> et j'ai <?php echo $age; ?> ans.</p>
</body>
</html>
