<?php
  $a = 2;
  $a = $a - 1;
  $a++;

  $b = 8;
  $b += 2;

  $c = $a + $b * $b;
  $d = $a * $b + $b;
  $e = $a * ($b + $b);
  $f = $a * $b / $a;
  $g = $b / $a * $a;
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Mystère</title>
</head>
<body>
  <h1>Valeurs des variables</h1>
  <ul>
    <li>$a = <?php echo $a; ?></li>
    <li>$b = <?php echo $b; ?></li>
    <li>$c = <?php echo $c; ?></li>
    <li>$d = <?php echo $d; ?></li>
    <li>$e = <?php echo $e; ?></li>
    <li>$f = <?php echo $f; ?></li>
    <li>$g = <?php echo $g; ?></li>
  </ul>
</body>
</html>
