<?php
  $prenom  = "Romain";
  $classe  = "BTS SIO 1";
  $langages = array("C#", "PHP", "HTML", "CSS", "JavaScript");

  $nbLangages = count($langages);

  if ($nbLangages < 3) {
      $niveau = "débutant";
  } elseif ($nbLangages <= 4) {
      $niveau = "débrouillé";
  } else {
      $niveau = "aguerri";
  }
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>La page de <?php echo $prenom; ?></title>
</head>
<body>
  <h1>Ma présentation</h1>
  <p>Bonjour, je m'appelle <?php echo $prenom; ?> et je suis en <?php echo $classe; ?>.</p>
  <p>Je suis un programmeur <?php echo $niveau; ?>. Je connais <?php echo $nbLangages; ?> langages de programmation :</p>
  <ul>
    <?php
    foreach ($langages as $langage) {
        echo '<li>' . $langage . '</li>';
    }
    ?>
  </ul>
</body>
</html>
