<?php
/**
 * Retourne une connexion PDO à la base de données Personnel
 */
function getBdd() {
    $host     = 'localhost';
    $dbname   = 'personnel';
    $user     = 'personnel_util';
    $password = 'secret';

    try {
        $pdo = new PDO(
            "mysql:host=$host;dbname=$dbname;charset=utf8",
            $user,
            $password,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        return $pdo;
    } catch (PDOException $e) {
        die("Erreur de connexion : " . $e->getMessage());
    }
}

/**
 * Protège une chaîne contre les injections XSS (JavaScript)
 */
function escape($valeur) {
    return htmlspecialchars($valeur, ENT_QUOTES, 'UTF-8');
}
?>
