<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des employés</title>
</head>
<body>
<?php
require_once 'fonctions.php';

$pdo = getBdd();

$stmt = $pdo->query("SELECT NomEmpl, PrenomEmpl FROM employe ORDER BY NomEmpl");
$employes = $stmt->fetchAll(PDO::FETCH_ASSOC);
$total = count($employes);
?>

<h1>Liste des employés</h1>

<ul>
    <?php foreach ($employes as $emp): ?>
        <li><?= escape($emp['NomEmpl']) ?> <?= escape($emp['PrenomEmpl']) ?></li>
    <?php endforeach; ?>
</ul>

<p>Total : <?= $total ?> employé(s)</p>

</body>
</html>
