<?php
require 'fonctions.php';

$message = '';

// Traitement du formulaire si soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $matricule  = trim($_POST['matricule'] ?? '');
    $nom        = trim($_POST['nom'] ?? '');
    $prenom     = trim($_POST['prenom'] ?? '');
    $cadre      = isset($_POST['cadre']) ? 'o' : 'n';
    $service    = $_POST['service'] ?? '';

    // Vérification : tous les champs obligatoires
    if ($matricule === '' || $nom === '' || $prenom === '' || $service === '') {
        $message = '<p style="color:red;">Tous les champs sont obligatoires.</p>';
    } else {
        try {
            $bdd = getBdd();
            $stmt = $bdd->prepare(
                'INSERT INTO employe (Matricule, NomEmpl, PrenomEmpl, CodeCadre, ServEmpl)
                 VALUES (:matricule, :nom, :prenom, :cadre, :service)'
            );
            $stmt->execute([
                ':matricule' => $matricule,
                ':nom'       => strtoupper($nom),
                ':prenom'    => $prenom,
                ':cadre'     => $cadre,
                ':service'   => $service,
            ]);
            $message = '<p>L\'ajout a réussi !</p>';

            // Réinitialisation après ajout réussi
            $matricule = $nom = $prenom = '';
            $cadre = 'n';
            $service = '';
        } catch (PDOException $e) {
            $message = '<p style="color:red;">Erreur : ' . escape($e->getMessage()) . '</p>';
        }
    }
}

// Récupération de la liste des services
$bdd = getBdd();
$services = $bdd->query('SELECT CodeServ, DesiServ FROM service ORDER BY DesiServ')->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajout d'un employé</title>
</head>
<body>
    <h1>Ajout d'un employé</h1>

    <form method="post" action="ajoutEmploye.php">
        <p>
            <label for="matricule">Matricule :</label>
            <input type="text" id="matricule" name="matricule"
                   value="<?= escape($matricule ?? '') ?>">
        </p>
        <p>
            <label for="nom">Nom :</label>
            <input type="text" id="nom" name="nom"
                   value="<?= escape($nom ?? '') ?>">
        </p>
        <p>
            <label for="prenom">Prénom :</label>
            <input type="text" id="prenom" name="prenom"
                   value="<?= escape($prenom ?? '') ?>">
        </p>
        <p>
            <label for="cadre">Cadre ?</label>
            <input type="checkbox" id="cadre" name="cadre"
                   <?= (isset($cadre) && $cadre === 'o') ? 'checked' : '' ?>>
        </p>
        <p>
            <label for="service">Service :</label>
            <select id="service" name="service">
                <?php foreach ($services as $s): ?>
                    <option value="<?= escape($s['CodeServ']) ?>"
                        <?= (isset($service) && $service === $s['CodeServ']) ? 'selected' : '' ?>>
                        <?= escape($s['DesiServ']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <p><input type="submit" value="Ajouter l'employé"></p>
    </form>

    <?= $message ?>
</body>
</html>
