<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau des employés</title>
</head>
<body>
<?php
require_once 'fonctions.php';

$pdo = getBdd();

$stmt = $pdo->query("SELECT Matricule, NomEmpl, PrenomEmpl FROM employe ORDER BY NomEmpl");
$employes = $stmt->fetchAll(PDO::FETCH_ASSOC);
$total = count($employes);
?>

<h1>Tableau des employés</h1>

<table>
    <tr>
        <th>Matricule</th>
        <th>Nom</th>
        <th>Prénom</th>
    </tr>
    <?php foreach ($employes as $emp): ?>
    <tr>
        <td><?= escape($emp['Matricule']) ?></td>
        <td><?= escape($emp['NomEmpl']) ?></td>
        <td><?= escape($emp['PrenomEmpl']) ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<p>Total : <?= $total ?> employé(s)</p>

</body>
</html>
