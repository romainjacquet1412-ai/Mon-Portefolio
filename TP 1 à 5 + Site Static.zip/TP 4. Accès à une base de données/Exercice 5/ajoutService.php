<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajout d'un service</title>
</head>
<body>
<?php
require_once 'fonctions.php';

$pdo     = getBdd();
$message = '';

// Traitement du formulaire si soumis
if (!empty($_POST['codeServ']) && !empty($_POST['desiServ'])) {
    $code = trim($_POST['codeServ']);
    $desi = trim($_POST['desiServ']);

    $stmt = $pdo->prepare("INSERT INTO service (CodeServ, DesiServ) VALUES (?, ?)");
    try {
        $stmt->execute([$code, $desi]);
        $message = "L'ajout a réussi !";
    } catch (PDOException $e) {
        $message = "Erreur lors de l'ajout : " . escape($e->getMessage());
    }
}

// Affiche la liste des services (mise à jour après insertion éventuelle)
$services = $pdo->query("SELECT CodeServ, DesiServ FROM service ORDER BY CodeServ")
               ->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Liste des services</h1>

<table>
    <tr>
        <th>Code</th>
        <th>Désignation</th>
    </tr>
    <?php foreach ($services as $s): ?>
    <tr>
        <td><?= escape($s['CodeServ']) ?></td>
        <td><?= escape($s['DesiServ']) ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<h1>Ajout d'un service</h1>

<form method="post" action="ajoutService.php">
    <label>Code :
        <input type="text" name="codeServ" maxlength="3">
    </label><br><br>
    <label>Désignation :
        <input type="text" name="desiServ" maxlength="30">
    </label><br><br>
    <input type="submit" value="Ajouter le service">
</form>

<?php if ($message): ?>
    <p><?= escape($message) ?></p>
<?php endif; ?>

</body>
</html>
