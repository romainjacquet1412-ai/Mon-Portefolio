<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajout d'un employé</title>
</head>
<body>
<?php
require_once 'fonctions.php';

$pdo     = getBdd();
$message = '';
$erreurs = [];

// Traitement du formulaire si soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $matricule = trim($_POST['matricule'] ?? '');
    $nom       = trim($_POST['nom'] ?? '');
    $prenom    = trim($_POST['prenom'] ?? '');
    $cadre     = isset($_POST['cadre']) ? 'o' : 'n';
    $servEmpl  = $_POST['servEmpl'] ?? '';

    // Validation : tous les champs sont obligatoires
    if ($matricule === '') $erreurs[] = "Le matricule est obligatoire.";
    if ($nom       === '') $erreurs[] = "Le nom est obligatoire.";
    if ($prenom    === '') $erreurs[] = "Le prénom est obligatoire.";
    if ($servEmpl  === '') $erreurs[] = "Le service est obligatoire.";

    if (empty($erreurs)) {
        $stmt = $pdo->prepare(
            "INSERT INTO employe (Matricule, NomEmpl, PrenomEmpl, CodeCadre, ServEmpl)
             VALUES (?, ?, ?, ?, ?)"
        );
        try {
            $stmt->execute([$matricule, $nom, $prenom, $cadre, $servEmpl]);
            $message = "L'ajout a réussi !";
            // Réinitialise les champs après succès
            $matricule = $nom = $prenom = $servEmpl = '';
            $cadre = 'n';
        } catch (PDOException $e) {
            $message = "Erreur lors de l'ajout : " . escape($e->getMessage());
        }
    }
}

// Récupère la liste des services pour le <select>
$services = $pdo->query("SELECT CodeServ, DesiServ FROM service ORDER BY DesiServ")
               ->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Ajout d'un employé</h1>

<?php if (!empty($erreurs)): ?>
    <ul style="color:red;">
        <?php foreach ($erreurs as $err): ?>
            <li><?= escape($err) ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<form method="post" action="ajoutEmploye.php">

    <label>Matricule :
        <input type="text" name="matricule" maxlength="4"
               value="<?= escape($matricule ?? '') ?>">
    </label><br><br>

    <label>Nom :
        <input type="text" name="nom" maxlength="25"
               value="<?= escape($nom ?? '') ?>">
    </label><br><br>

    <label>Prénom :
        <input type="text" name="prenom" maxlength="20"
               value="<?= escape($prenom ?? '') ?>">
    </label><br><br>

    <label>Cadre ?
        <input type="checkbox" name="cadre"
               <?= (isset($cadre) && $cadre === 'o') ? 'checked' : '' ?>>
    </label><br><br>

    <label>Service :
        <select name="servEmpl">
            <?php foreach ($services as $s): ?>
                <option value="<?= escape($s['CodeServ']) ?>"
                    <?= (isset($servEmpl) && $servEmpl === $s['CodeServ']) ? 'selected' : '' ?>>
                    <?= escape($s['DesiServ']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </label><br><br>

    <input type="submit" value="Ajouter l'employé">

</form>

<?php if ($message): ?>
    <p><?= escape($message) ?></p>
<?php endif; ?>

</body>
</html>
