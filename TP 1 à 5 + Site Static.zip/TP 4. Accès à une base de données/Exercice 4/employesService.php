<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des employés du service</title>
</head>
<body>
<?php
require_once 'fonctions.php';

if (empty($_POST['codeServ'])) {
    die("Aucun service sélectionné. <a href='service.php'>Retour</a>");
}

$codeServ = $_POST['codeServ'];
$pdo = getBdd();

// Récupère le nom du service
$stmtS = $pdo->prepare("SELECT DesiServ FROM service WHERE CodeServ = ?");
$stmtS->execute([$codeServ]);
$service = $stmtS->fetch(PDO::FETCH_ASSOC);

if (!$service) {
    die("Service introuvable. <a href='service.php'>Retour</a>");
}

// Récupère les employés du service
$stmtE = $pdo->prepare(
    "SELECT Matricule, NomEmpl, PrenomEmpl
     FROM employe
     WHERE ServEmpl = ?
     ORDER BY NomEmpl"
);
$stmtE->execute([$codeServ]);
$employes = $stmtE->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Liste des employés du service <?= escape($service['DesiServ']) ?></h1>

<table>
    <tr>
        <th>Matricule</th>
        <th>Nom</th>
        <th>Prénom</th>
    </tr>
    <?php foreach ($employes as $emp): ?>
    <tr>
        <td><?= escape($emp['Matricule']) ?></td>
        <td><?= escape($emp['NomEmpl']) ?></td>
        <td><?= escape($emp['PrenomEmpl']) ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<p><a href="service.php">Retour</a></p>

</body>
</html>
