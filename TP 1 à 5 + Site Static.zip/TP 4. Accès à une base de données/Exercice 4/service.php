<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Sélection du service</title>
</head>
<body>
<?php
require_once 'fonctions.php';

$pdo = getBdd();
$stmt = $pdo->query("SELECT CodeServ, DesiServ FROM service ORDER BY DesiServ");
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Choix d'un service</h1>

<form method="post" action="employesService.php">
    <label for="service">Service :</label>
    <select name="codeServ" id="service">
        <?php foreach ($services as $s): ?>
            <option value="<?= escape($s['CodeServ']) ?>">
                <?= escape($s['DesiServ']) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <br><br>
    <input type="submit" value="Afficher les employés">
</form>

</body>
</html>
